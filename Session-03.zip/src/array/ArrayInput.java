package array;

import java.util.Scanner;

public class ArrayInput {

	public static void main(String[] args) {
	
		Scanner sc = new Scanner(System.in);
		
		int size;
		System.out.println("enter size of array");
		size = sc.nextInt();
		
		int n[] =new int[size];
		
		//read data from user and store on array variable
		System.out.println("enter data for array ");
		for(int i=0; i<n.length;i++) {
			
			n[i] = sc.nextInt(); 
		}

		//get the sum
		int s=0;
		//print all data 
		for(int i=0; i<n.length;i++)
		{
			System.out.println(n[i]);
			s+=n[i];
		}
	
		
		//print in reverse
		for(int i=n.length-1;i>=0;i--) {
			
			System.out.println(n[i]);
		}
		
		//sum of all number 
		System.out.println(s);
	}

}
