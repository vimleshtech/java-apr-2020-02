package innerclass;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStreamReader;

public class Ex {

	public static void main(String[] args) throws FileNotFoundException {

		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		BufferedReader br1 = new BufferedReader(new FileReader(""));
		
		
		
		Test.Hello o = new Test.Hello();
		
		o.b();
		o.a();
		
		Test.Hello.a();		
		System.out.print("");
		System.err.print("");
		
		
		
		

	}

}
