package innerclass;

public class Test {

	
	public static class Hello{
		
		public static void a() {
			System.out.println("hi a");
		}
		
		public void b() {
			System.out.println("hi b");
		}
	}

	
}
