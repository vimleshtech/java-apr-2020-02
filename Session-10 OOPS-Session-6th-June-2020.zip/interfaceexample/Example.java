package interfaceexample;

public class Example implements Ia,Ib{

	@Override
	public void mul(int a, int b) {
		// TODO Auto-generated method stub
		
		System.out.println(a*b);
	}

	@Override
	public void add(int a, int b) {
		// TODO Auto-generated method stub
		System.out.println(a+b);
	}

	@Override
	public int sub(int a, int b) {
		// TODO Auto-generated method stub
		return a-b;
	}

	@Override
	public void welecome() {
		// TODO Auto-generated method stub
		System.out.println("welcome to corona world.. !!!!");
		
		
	}

	
}
