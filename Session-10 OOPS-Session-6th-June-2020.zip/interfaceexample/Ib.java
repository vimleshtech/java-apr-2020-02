package interfaceexample;

public interface Ib {
	void mul(int a, int b);
	
}
