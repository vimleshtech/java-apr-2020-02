package interfaceexample;

public class Startup {

	final static int d=10;
	
	public static void main(String[] args) {

		
		//d =11; //error
		System.out.println(d);
		
		Ia a = new Example();
		a.add(11, 55);
		a.sub(11, 2);
	
		
		Example e = new Example();
		e.add(11, 3);
		e.sub(11, 3);
		e.mul(11, 4);
		
		
	}

}
