package interfaceexample;

public class A {

	void add() {
		System.out.println("add");
	}
	final void sub() {
		System.out.println("sub");
	}
}
