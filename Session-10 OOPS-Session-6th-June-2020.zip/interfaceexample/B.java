package interfaceexample;

public class B  extends A{

	void add() {
		System.out.println("new add");
	}
	
	
}
