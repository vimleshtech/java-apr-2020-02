package abstractexample;

public class DigitalCal extends Calc {

	@Override
	void add(int a, int b) {
		// TODO Auto-generated method stub
			System.out.println(a+b);
	}

	@Override
	String getName(String fname, String lname) {
		// TODO Auto-generated method stub
		return fname+" "+lname;
	}	
	
}
