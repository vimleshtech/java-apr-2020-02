package abstractexample;

public  abstract class Calc {
	
		//Abstract method
		abstract void add(int a, int b); 
		abstract String getName(String fname,String lname);

		//Non-abstract method
		void sub(int a, int b){
			//statement 
			System.out.println(a-b);
		}
}
