package abstractexample;

public class IncomeTax  extends Calc{

	@Override
	void add(int a, int b) {

		System.out.println("sum of two numbers "+(a+b));
		
	}

	@Override
	String getName(String fname, String lname) {
		// TODO Auto-generated method stub
		return "User full name "+fname.trim()+" "+lname.trim();
	}
	void tax(int amt){

		if(amt>10000) {
			System.out.println(amt*.18);
		}else {
			System.out.println(amt*.10);
		}
	}


}
