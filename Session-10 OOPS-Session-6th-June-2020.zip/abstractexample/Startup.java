package abstractexample;

public class Startup {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Calc c = new DigitalCal();
		c.add(11, 3);
		c.sub(11, 4);
		String name =c.getName("Rahul", "Srivastava");
		System.out.println(name);
		
		
		IncomeTax t = new IncomeTax();
		name =  t.getName("Raman", "Srivastava");
		System.out.println(name);
		t.tax(100333);
		
		
	}

}
