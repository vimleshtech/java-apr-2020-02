package example;

public class Login {

	public static void main(String[] args) {

		Users u = new Users();		
		u.createUser(101, "rahul", "raman@gmail.com", "rahul@123");
		u.getUser();
		
		System.out.println("is credential match ?"+u.validateUser("test","rahul@123"));
		System.out.println("is credential match ?"+u.validateUser("raman@gmail.com","rahul@123"));
		
		//u.uid=1;
		u.uname ="ffff"; //procteted, default, public can be access within package 
		

		//static member can be accessed with or without object
		u.country = "India";
		Users.country ="US";
		
		System.out.println(u.country);//US
		System.out.println(Users.country);//US 
		
		
		//static method can be accessed with or without object
		u.welcome();
		Users.welcome();

	}

}
