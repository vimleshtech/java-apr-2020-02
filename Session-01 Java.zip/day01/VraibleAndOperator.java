package day01;

public class VraibleAndOperator {

	public static void main(String[] args) {
		
		// Declartion of variables
		byte b=11;
		short s =6667;
		int i =5555;
		
		long l =6665444;
		long l2 =6665444666640000l; //ending with l (L)
		System.out.println(b);
		System.out.println(s);
		System.out.println(i);
		System.out.println(l);
		System.out.println(l2);
		
		///float
		float f =66666;
		float f2 =66666.5677f;
		double d = 66677774444444444.444566566644;
		double d2 = 66677774444444444.444566566644d;
		
		System.out.println(f);
		System.out.println(f2);
		System.out.println(d);
		System.out.println(d2);
		
		//boolean
		boolean bb=true;
		System.out.println(bb); //default is false

		
		//char 
		char c='a';
		System.out.println(c);
		
		//get ascii code
		int as = c; //convert to int and get ascii
		System.out.println(as);
		
		//String 
		String ss="flkjfufgjy dfghfhg5556";
		System.out.println(ss);
		
		
		//increment and decrement
		int x,y;
		x=0;
		y=0;
		
		System.out.println(x++);//0   - post increment (first print then incremnt)
		System.out.println(++y);//1	   - pre increment  (first increment then print)
		
		System.out.println(x);//1 
		System.out.println(y);//1
		
		
		
	}

}
