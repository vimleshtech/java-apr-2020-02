package day01;

public class ScopeOfVariable {

	//Global variable	
	//instance variable
	int x;
	
	//static variable 
	static int y;
	
	public static void main(String[] args) {
		
		/* Example 1: --------------- */
		//access static variable
		y =100;
				
		//access non-static (instance variable)
		//x =11; //error
		ScopeOfVariable o = new ScopeOfVariable();
		o.x =556;
				
		System.out.println(y);
		System.out.println(o.x);
				
		/* Example 2: ----------------- */
		ScopeOfVariable o1 = new ScopeOfVariable();
		ScopeOfVariable o2 = new ScopeOfVariable();
		System.out.println(o1);
		System.out.println(o2);
		
		//access variable and store data 
		o1.x =11;
		o1.y =2;
		
		o2.x =103;
		o2.y =4;
				
		System.out.println(o1.x);//11
		System.out.println(o1.y);//  4   //last value will be overwrite 
		
		System.out.println(o2.x);//103
		System.out.println(o2.y);//4
				
	}

}
