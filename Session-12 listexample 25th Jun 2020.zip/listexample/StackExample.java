package listexample;

import java.util.Stack;

public class StackExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Stack<String> st=new Stack();
		st.push("Nitin");
		st.push("Raman");
		st.push("Ridhi");
		
		System.out.println(st.size());
		System.out.println( st.pop());
		System.out.println(st.size());
	}

}
