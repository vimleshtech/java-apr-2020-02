package listexample;

import java.util.Iterator;
import java.util.Vector;

public class VectorExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Vector<String> vk = new Vector();
		vk.add("fifjhgf");
		vk.add("f1ifjhgf");
		vk.add("4fifjhgf");
		vk.add("5fifjhgf");
		
		
		Iterator it = vk.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}

	}

}
