package listexample;

import java.util.ArrayList;
import java.util.Iterator;

public class ArrayListExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ArrayList al  =new ArrayList();
		
		al.add(11);
		al.add(555);
		al.add(666);
		al.add("Raman");
		al.add(true);
		
		//ArrayList<Integer> data  =new ArrayList<Integer>();
		//ArrayList<Integer> data  =new ArrayList<>();
		ArrayList<Integer> data  =new ArrayList();
		data.add(6666);
		data.add(8);
		data.add(4);
		data.add(10);
		
		System.out.println(data.size());
		data.remove(1);//1 is index
		System.out.println(data.size());
		
		for(int i=0;i<data.size();i++) {
			System.out.println(data.get(i));
		}
		
		//or
		for(Integer x : data) {
			System.out.println(x);
		}
		
		//or
		Iterator it = data.iterator();
		while(it.hasNext()) {
			System.out.println(it.next());
		}
	}

}
