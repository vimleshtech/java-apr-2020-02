package loop.example;

import java.util.Scanner;

public class ForLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i=1; i<10;i++) {
			System.out.println(i);
		}
		
		//print in desc
		for(int i=1; i>0;i--) {
			System.out.println(i);
		}
		
		//wap to check given number is prime number or not 
		
		Scanner sc =new Scanner(System.in);
		System.out.println("enter number ");
		int n = sc.nextInt();
		boolean flag =true;
		
		for(int x=2; x<n/2; x++) {
			
			if(n%x ==0)
			{
				flag =false;
				break;
			}
		}
		
		if(flag)
			System.out.println("prime number");
		
		else
			System.out.println("not prime");
		
		
	}

}
