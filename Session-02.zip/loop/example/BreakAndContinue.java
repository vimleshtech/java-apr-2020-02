package loop.example;

public class BreakAndContinue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		//break
		for(int i=1; i<10;i++) {
			
			if(i%4 ==0)
				break;
			System.out.println(i);
		}

		//continue
		for(int i=1; i<10;i++) {
			
			if(i%4 ==0)
				continue;
			System.out.println(i);
		}
		//1 2 3 5 6 7 9 
		

		
	}

}
