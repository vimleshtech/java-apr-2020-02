package loop.example;

import java.util.Scanner;

public class WhileLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		int i=1; //init
		
		while(i<=10) {//condition 
				
				System.out.println(i);
				i++; //increment
			
		}
		
		//print series in same line
		 i=1; //init
			
			while(i<=10) {//condition 
					
					System.out.print(i);
					i++; //increment
				
			}
			
			//print the series in desc order
			 i=10; //init
				
				while(i>0) {//condition 
						
						System.out.println(i);
						i--; //decrement
					
				}
				
				//Q, wap to get sum of all even and odd numbers between two given range
				int sn,en;
				int se=0, so=0;
				
				Scanner sc = new Scanner(System.in);
				System.out.println("enter first and last number ");
				
				sn = sc.nextInt();
				en = sc.nextInt();
				
				
				while(sn<=en) {
					
					if(sn%2==0)
							se+=sn;
					else
							so+=sn;
					sn++;
				}
			
			System.out.println("sum of all even nun "+se);
			System.out.println("sum of all odd nun "+so);
			
	
			//wap to print table of given number
			int t;
			System.out.println("enter numer for table ");
			t = sc.nextInt();
			
			i=1;
			while(i<=10) {
				
				System.out.println(i*t);
				i++;
			}
			
			
			//wap to get the factorial of given number
			//num = 6
			// 6*5*4*3*2*1 = ?
			
			int fn;
			
			System.out.println("enter num ");
			fn = sc.nextInt();
			
			int fact=1;
			
			while(fn>1) {
				
				fact*=fn;
				fn--;
			}
			System.out.println("factorial is "+fact);
			
			//wap to print given in reverse
			// 398 = 893
			
			System.out.println("enter num ");
			fn = sc.nextInt();
			se =fn;
			
			int rev=0;
			while(fn>0) {
				
				int m = fn%10;
				rev = (rev*10)+m;
				
				fn = fn/10;
			}
			
			System.out.println(rev);
			//check the given number is palindrom or not
			System.out.println(se==rev);
			
			//wap to take number from user and print the febanacci series
			//last two number sum will next number
			// 1 2 3 5 8 ... 
			int n1,n2;
			
			System.out.println("enter n1 and n2 ");
			
			n1=sc.nextInt();
			n2 =sc.nextInt();
			
			System.out.println(n1);
			System.out.println(n2);
			i=1;
			while(i<=10) {
				
				int next = n1+n2;
				System.out.println(next);
				
				n1 =n2;
				n2= next;
				i++;
			}
			
			
	}

}
