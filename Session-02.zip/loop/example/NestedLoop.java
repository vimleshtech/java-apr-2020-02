package loop.example;

public class NestedLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		for(int i=1;i<4;i++) {
			
			for(int c=1; c<4;c++) {
				System.out.print(c);
			}
			System.out.println();//new line 
		}
		
		//in asc
		for(int i=0;i<4;i++) {
			
			for(int c=0; c<=i;c++) {
				System.out.print(c);
			}
			System.out.println();//new line 
		}
		//in desc
				for(int i=0;i<4;i++) {  
					
					//i =2
					//c =0  <4-2=2
					for(int c=0; c<4-i;c++) {
						System.out.print(c);
					}
					System.out.println();//new line 
				}
	}

}
