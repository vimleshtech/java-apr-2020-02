package loop.example;

public class ForeachLoop {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n[]= {1111,555,33,554,333};
		
		System.out.println(n);
		
		//wap to get largest value from array 
		int max=n[0];
		//wap to get lowest value from array
		int min=n[0];
		
		for(int x : n) {
			System.out.println(x);
			
			if(max<x)
				max =x;
		
			if(min>x)
				min=x;
		}
		
		System.out.println(max);
		System.out.println(min);
		
		
	}

}
