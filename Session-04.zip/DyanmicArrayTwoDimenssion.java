package array;

import java.util.Scanner;

public class DyanmicArrayTwoDimenssion {

	public static void main(String[] args) {

		int rsize=0,csize=0;
		
		Scanner sc = new Scanner(System.in);
		System.out.println("enter row size and col size ");
		rsize = sc.nextInt();
		csize = sc.nextInt();
		
		String user_data[][]= new String[rsize][csize];
		
		//store data in array 
		for(int r=0; r<rsize;r++) {
			
			for(int c=0; c<csize;c++) {
				
				user_data[r][c]= sc.next();
				
			}
		}
		
		//
		for(String row[] : user_data) {
			for(String col: row) {
				System.out.print(col+"\t");
			}
			System.out.println();
		}	

	}

}
