package errorhandling;

import java.util.Scanner;

public class ExceptionExample {

	public static void main(String[] args) {

		int n1,d,o;
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter number ");
		n1 = sc.nextInt();
		
		System.out.println("enter divisor ");
		d =sc.nextInt();
		
		try {
			
				
				o = n1/d;
				System.out.println("output is "+o);
		}
		catch (ArithmeticException e) {
			// TODO: handle exception
			System.out.println(e);
		}
		catch (ArrayIndexOutOfBoundsException e) {
			// TODO: handle exception
			System.out.println(e);
		}
		catch(Exception ex) //here ex is generic type error
		{
			System.out.println(ex);
		}
		finally {
			System.out.println("end o code ");
		}
		

	}

}
