package errorhandling;

import java.util.Scanner;

public class ThrowExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int n[] =new int[4];
		int i=0;
		Scanner sc =new Scanner(System.in);
		
		
		while(i<4) {			
		
			System.out.println("enter age ");
			int age= sc.nextInt();
			
			try {
				
			
					if(age>85 && age<0) {
						Exception er = new Exception("There is no live");
						throw er;
					}
					n[i] = age;
					i++;
			}
			catch (Exception e) {
				// TODO: handle exception
				System.out.println(e);
			}
			
		}
		
		//print
		for(int x: n) {
			System.out.println(x);
		}
		
	}

}
