package errorhandling;

import java.io.FileNotFoundException;
import java.io.FileReader;

public class Throws {

	public static void main(String[] args) throws FileNotFoundException {

		FileReader fr = new FileReader("C:\\Users\\vkumar15\\Desktop\\djnago-project\\out.txt");
		System.out.println(fr);
		
		

	}

}
