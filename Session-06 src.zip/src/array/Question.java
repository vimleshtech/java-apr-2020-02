package array;

public class Question {
	
	public static void main(String[] args) {
	
		String patternToSearch = "abcdef";
		String actualPattern = "aabccdecfhabcdefaabcdef";
		
		char pts[]= patternToSearch.toCharArray();
		char ap[] = actualPattern.toCharArray();
		
		int count = 0;
		int subStringStartIndex  =-1;
		int subStringEndIndex = -1;
		
		for(int i=0; i< ap.length; i++) {
			char c = ap[i];
			
			if(c == pts[count]) {
				
				++count;
				
				if(count == pts.length) {
					
					subStringEndIndex = i;
					System.out.println(actualPattern.substring(subStringStartIndex+1, subStringEndIndex+1));
					subStringStartIndex = i;
					count = 0;
				}
			}
			
		}
	}
}