package array;

import java.util.Scanner;

public class StringExample {

	public static void main(String[] args) {

		String s1,s2;
		
		Scanner sc = new Scanner(System.in);
		
		System.out.println("enter data ");
		s1=sc.nextLine();
		
		//print as it is
		System.out.println(s1);
		//length
		System.out.println(s1.length());
		//upper case
		System.out.println(s1.toUpperCase());
		//lower case
		System.out.println(s1.toLowerCase());
		//replace
		System.out.println(s1.replace("a", "xy"));
		//trim
		System.out.println(s1.trim()); 
		
		//get the position 
		int pos = s1.indexOf("m"); //return -1 if given char or word not match
		System.out.println(pos);
		
		//concat 
		String ns = s1.concat("new String");
		System.out.println(ns);
		
		///cut string 
		String s = s1.substring(2,6);
		System.out.println(s);
		
		
		//charAt
		char c = s1.charAt(1);
		System.out.println(c);
		int ascii =c; //convert char to assici 
		System.out.println(ascii);
		
		//toChararray 
		char cc[] = s1.toCharArray();
		System.out.println(cc.length); //char count
		for(char c1: cc) {
			System.out.println(c1);
		}
		
		
		//conditional 
		if(s1.contains("ma")) {
			
			System.out.println("ma exist");
		}
		else {
			System.out.println("ma is not match");
		}
		//
		if(s1.startsWith("ra")) {
			System.out.println("ra is match at start");
		}
		else {
			System.out.println("not started with ra");
		}
		//
		if(s1.endsWith("n")) {
			System.out.println("end with n");
		}else {
			System.out.println("not end with n");
			
		}
		//
		if(s1.equals("raman sinha")) {
			System.out.println("name exact match");
		}else {
			System.out.println("name exact not match");
		}
		//
		if(s1.equalsIgnoreCase("raman sinha")) {
			System.out.println("name exact match");
			
		}else {
			System.out.println("name exact not match");
		}

	}

}
