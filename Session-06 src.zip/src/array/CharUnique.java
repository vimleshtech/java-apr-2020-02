package array;

import java.util.Scanner;

public class CharUnique {

	public static void main(String[] args) {
		
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
				
		System.out.println("enter string");
		String str = sc.nextLine();

		//boolean default value is false 
		boolean b[] =new boolean[256];
		
		for(int ascii : str.toCharArray() ) {
			
			if(b[ascii]) {
				System.out.println("String contains duplicate char");
				break;
			}
			else {
				b[ascii]=true;
			}
		}
		
		
	}

}
