package array;

public class TwoDimenssionArray {

	public static void main(String[] args) {

		String data[][] = {{"Nitin","Male"},{"Rahul","Male","23"},{"Monkia","female"}}; 
		
		System.out.println("length "+data.length); //row count
		System.out.println("col count"+data[1].length); //first row -> col count of 2 rows
		
		//Read data from
		System.out.println(data);
		System.out.println(data[1]);
		System.out.println(data[1][0]+"\t"+data[1][1]);//first row , first column by index
		
		
		//Iterate using for loop
		for(int i=0; i<data.length;i++) { //row 
			
			for(int j=0;j<data[i].length;j++) { //col
				System.out.print(data[i][j]+"\t"); //print value 
			}
			System.out.println(); //new line 
		}
		
		//Iterate using for each/advance loop
		for(String row[] : data) {  // open table {{1,2},{3,4},{}} and get the row {1,2}, read row							
			
			for(String col: row) {  //read data from row to col (value)
				
				System.out.print(col+"\t");
			}
			System.out.println();
		}

	}

}
