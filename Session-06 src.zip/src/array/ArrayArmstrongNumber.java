package array;

import java.util.Scanner;

public class ArrayArmstrongNumber {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		int size;
		System.out.println("enter size of array");
		size = sc.nextInt();
		
		int n[] =new int[size];
		
		//read data from user and store on array variable
		System.out.println("enter data for array ");
		for(int i=0; i<n.length;i++) {
			
			int num;
			num = sc.nextInt();
			if(num>=100 && num<=999)
			{
				n[i] = num;
			}else {
				System.out.println("invalid input, enter new input");
			}
			
		}

		
		//armstrong 
		for(int x : n) { //iterate the array element
			int sum=0,num=x;
			
			
			while(x>0) {				
				int d=x%10;			
				sum+=Math.pow(d, 3);			
				x = x/10;			
			}
			
			//check the match
			if(num == sum) {
				System.out.println("number is armstrong "+num);
			}
			
		}
		

		

	}

}
