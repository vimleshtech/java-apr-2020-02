package function;

import java.util.Date;


public class Function {

	//global variale 
	//instance variable
	int num =100; //instance variable allocates seperate memory fo revery object, and can be access with object only
	//static variable
	static String country="India"; //static allocates single memory, and can be access without object
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		//access to static varible
		System.out.println("Static variable "+country);
		
		//access to instance variable
		Function fun=new Function();
		System.out.println("instance variable "+fun.num);
		
		//call or invoke to function 
		information();
		Date today = getDate();
		System.out.println("now :"+today);
		
		
		addition(11, 44);
		addition(151, 446);
		
		//
		int out = multiplication(33, 5);
		System.out.println(out);
		
		//Call to recurrsive function 
		int f = factorial(6);
		System.out.println(f);
	}

	
	
	//-No argument no return
	public static void information() {
		
		System.out.println("We are learning java-function concept");
		System.out.println("This class contains following functions i. information ii. getDate iii. addition iv. tax and main method .");
		
	}
	//-No argument with return
	public static Date getDate() {
		
		return new Date();//get system current datetime
	}
	//-Argument with no return
	public static void addition(int n1, int n2) {
		int n =n1+n2;
		System.out.println("sum of two values "+n);
	}
	
	//-Argument with return
	public static int multiplication(int a, int b) {
		int c =a*b;
		return c;
	}
	//-Recurrsive function : function which call or invoke itself i.e. called recussive function 
	public static int factorial(int n) {
		if (n ==1) {
			return n;
		}else {
			return n*factorial(n-1);
		}
	}


}
