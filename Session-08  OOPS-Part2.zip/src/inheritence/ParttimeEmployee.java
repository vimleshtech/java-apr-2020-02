package inheritence;

//contructor must be implemented in child class if parent class contains contructor 

public class ParttimeEmployee extends Employee { //here Employee is parent class, and ParttimeEmployee is child class
	//and in java, parent class is also known super class ,and child class known as derived class 

	private int msal;
	private double tax;
	ParttimeEmployee(int eid,String name, String email, String dept,int msal){
		super(eid,name,email,dept);  //super is method which refere to parent class , super() call to parent class constructor	
		
		this.msal = msal;
	}
	
	void compouteTax() {
		
		if(this.msal<300000) {
			this.tax =0;
		}
		else if(this.msal<500000) {
			this.tax = (this.tax-300000)*.05;			
		}
		else if(this.msal<1000000) {
			this.tax =12500+ (this.tax-500000)*.2;			
		}else {
			this.tax =112500+ (this.tax-1000000)*.3;
		}		
		
	}
	String employeeDetails() {
		return super.getEmployee()+" , msal "+this.msal+"\t and tax "+this.tax;
	}
	
	
}
