package inheritence;

public class Starter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Employee o = new Employee(101, "Nitin", "nitin@gmail.com", "HR");
		System.out.println(o.getEmployee());

		///
		ParttimeEmployee e =new ParttimeEmployee(101, "Nitin", "nitin@gmail.com", "HR", 78000);
		e.compouteTax();
		System.out.println(e.employeeDetails());

		
		FulltimeEmployee f =new FulltimeEmployee(11, "Raman", "raman", "IT", 50000);
		f.computTax();
		System.out.println(f.employeeDetails());
				
	}

}
