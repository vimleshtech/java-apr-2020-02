package inheritence;

public class Employee {

		private int eid;
		private String ename;
		private String email;
		private String dept;
		
		Employee(int eid, String ename, String email, String dept) {
			this.eid = eid;
			this.ename =ename;
			this.email =email;
			this.dept = dept;
		}
		public String getEmployee() {
			
			return "Employee Details "+this.eid+"\t"+this.ename+"\t"+this.email+"\t"+this.dept;
		}
	
}
