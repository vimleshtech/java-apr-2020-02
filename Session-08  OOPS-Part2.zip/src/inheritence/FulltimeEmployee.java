package inheritence;

public class FulltimeEmployee extends Employee {

	private int basic;
	private double hra;
	private double msal;	
	private double ysal;
	
	private double tax;
	
	FulltimeEmployee(int eid,String name, String email, String dept,int basic){
		super(eid,name,email,dept);  //super is method which refere to parent class , super() call to parent class constructor	
		
		this.basic = basic;
	}

	void computTax() {
		
		this.hra = this.basic*.5;
		this.msal = this.basic+this.hra;
		this.ysal = this.msal*12;
		
		
		if(this.msal<300000) {
			this.tax =0;
		}
		else if(this.msal<500000) {
			this.tax = (this.tax-300000)*.05;			
		}
		else if(this.msal<1000000) {
			this.tax =12500+ (this.tax-500000)*.2;			
		}else {
			this.tax =112500+ (this.tax-1000000)*.3;
		}
		
	}
	String employeeDetails() {
		return super.getEmployee()+" , msal "+this.msal+"\t ysal "+this.ysal+" and tax "+this.tax;
	}
	
	
}
