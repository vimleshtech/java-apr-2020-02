package example;

public class Cller {

	public static void main(String[] args) {
		
		Constructor o1 =new Constructor(); //Constructor() - invoke to construcor 
		Constructor o2 =new Constructor();
		
		System.out.println(o1.getObject());
		System.out.println(o2.getObject());		
				
		Constructor o3 =new Constructor("Object1");
		Constructor o4 =new Constructor("Object2");
		
		System.out.println(o3.getObject());
		System.out.println(o4.getObject());
		
		///Create new object and pass the reference of existing object
		Constructor o5 =new Constructor(o2);
		Constructor o6 =new Constructor(o4);
		
		System.out.println(o5.getObject());
		System.out.println(o6.getObject());
		
		

	}

}
