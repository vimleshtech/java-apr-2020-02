package example;

import javax.swing.SortingFocusTraversalPolicy;

public class Users {

	
 	private int uid;
 	protected String uname;
 	private String email;
 	private String pwd;
	
 	/* static member */
 	static String country;
 	
	void createUser(int uid, String uname,String email, String pwd) {		
		this.uid=uid;
		this.uname=uname;
		this.email=email;
		this.pwd=pwd;
	}
	
	boolean validateUser(String email, String pwd) {	
		return 	this.email.equals(email) && this.pwd.equals(pwd) ? true : false;	
	}	
	void getUser() {		
		System.out.println("----User Details -----");
		System.out.println("Uname "+this.uname+"\tEmail "+this.email);
	}
	
	/* static method */
	static void welcome() {
		System.out.println("in static method");
	}
	
}
