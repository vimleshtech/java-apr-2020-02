package example;

public class Constructor {

	String oName;
	
	//Default constructor 
	Constructor(){		
		System.out.println("Object initialized");
		this.oName="Undefined";
	}
	//Parameterize Constructor 
	Constructor(String name){
		this.oName=name;
	}
	
	//Copy Constructor : take a reference of existing object and create new object
	Constructor(Constructor o){
		this.oName = o.oName; //copy data from existing object to new object 
	}
	//Methods 
	String getObject() {
		return "Name of the Object is "+this.oName;
	}
	
}
