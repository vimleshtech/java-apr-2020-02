package example;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.TimeZone;

public class Login {

	public static void main(String[] args) {

		
		final Date date = new Date();
		System.out.println(date);
		final String ISO_FORMAT = "yyyy-MM-dd'T'HH:mm:ss.SSS zzz";		
		final SimpleDateFormat sdf = new SimpleDateFormat(ISO_FORMAT);
		final TimeZone utc = TimeZone.getTimeZone("UTC");
		sdf.setTimeZone(utc);
		System.out.println(sdf.format(date));
		
		/*
		String ns = "2020-05-22T00:49:25.609+05:30";
		sdf.setTimeZone(utc);
		System.out.println(sdf.format(ns));
		*/
		
		
		/*
		
		Users u = new Users();		
		u.createUser(101, "rahul", "raman@gmail.com", "rahul@123");
		u.getUser();
		
		System.out.println("is credential match ?"+u.validateUser("test","rahul@123"));
		System.out.println("is credential match ?"+u.validateUser("raman@gmail.com","rahul@123"));
		
		//u.uid=1;
		u.uname ="ffff"; //procteted, default, public can be access within package 
		

		//static member can be accessed with or without object
		u.country = "India";
		Users.country ="US";
		
		System.out.println(u.country);//US
		System.out.println(Users.country);//US 
		
		
		//static method can be accessed with or without object
		u.welcome();
		Users.welcome();
		 */
		
	}

}
